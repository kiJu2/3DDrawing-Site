                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3674539
hand prosthesis SDC by SWISS_DESIGN_CENTER is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

Here is a hand prosthesis, designer in 3D printing as part of a student project in industrial design at the Swiss Design Center in Lausanne, Switzerland.

The goal is to provide a portable prosthesis, with a design between the realistic hand and the robotic hand.

Based on historical research and market research, it was found that existing products did not necessarily match users. The creation of a hand print prosthesis in 3D, on commercial printers, allows printing at low cost and customizable simply for each user, regardless of their measurements, their ages, their handicap ... An optimization of the 3D model in the second time makes printing easier, with the production and evolution of functional prototypes. The goal was to make a royalty-free product with an ethical approach, in order to achieve a product outside the traditional industrial codes.

the hand is fully printed in classic and flexible PLA.

See page 7 for mounting
-----------------------------------------------------------------------------------------------------------------
Voici une prothèse de main designer en impression 3D dans le cadre d'un projet d'etudiant en designe industriel au sein de l'ecole Swiss Design Center à Lausanne en Suisse.

L'objectif est de fournir une prothèse portable, avec un design entre la main realiste et la main robotique.

Suite à une recherche historique et une étude du marché, il en est ressorti que les produits existants ne correspondaient pas forcément aux utilisateurs. La création d’une prothèse de main imprimer en 3D , sur des imprimantes du grand commerce, permet une impression à faible cout et personnalisable simplement pour chaque utilisateur, indépendamment de leurs mensurations, leurs âges, leur handicape… Une optimisation du modèle 3D en deuxième temps permet de faciliter les impressions, avec réalisation et évolution de prototypes fonctionnels. L’objectif était de réaliser un produit libre de droits avec une démarche éthique, afin de réaliser un produit en dehors des codes industriels traditionnel.

la main est entierement imprimé en PLA classique et flexible.

Voir la page 7 pour le montage

# Print Settings

Printer Brand: Ultimaker
Printer: Ultimaker 2
Rafts: No
Supports: Yes
Resolution: 0.1
Infill: 25
Filament_brand: AddiFrance
Filament_material: PLA