                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2542369
Tika Alpaca (movable legs!) by TikaDesign is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

A friendly pack animal to carry you through the day. With two pairs of movable legs and a spirit for adventure, this alpaca will surely brighten your life. 
Alpacas get lonely. So why not print in pairs?
Get a special edition traveler alpaca, complete with saddle bags, by [becoming our patron](https://www.patreon.com/Tika2017) or through [Gumroad](https://gumroad.com/mikayeap). 

Designed as an aesthetic, multi-functional test and calibration model, this alpaca works great for testing your printer's bridging, overhang, supports, and bed adhesion capability as shown [here](https://www.youtube.com/watch?v=mYkn7fa1tC0).

If you like this smooth, clean look, you might like [Grumbo](https://www.thingiverse.com/thing:2619384), our solid, blocky elephant.

** Note **
Make sure you give your new best friend enough infill, otherwise the tail might detach.  
You can print this alpaca down to 60% of provided size (baby alpacas!!!) if your printer can work with a bridge of clearance 0.3mm. The original has 0.5mm clearance. 
Inspiration from: [LeFabshop Elephant](https://www.thingiverse.com/thing:257911)

Do you want a discount to print this on 3D Hubs? Here you go: http://3dhubs.refr.cc/5D323XS
How about discounted filament? http://r.sloyalty.com/r/vowQk944fAdh 
See apps, projects, and other designs we make at [tika.io](http://tika.io)


# Print Settings

Printer: Printrbot Play
Rafts: No
Supports: Doesn't Matter
Infill: 20%

Notes: 
Print the first layer slow, crank cooling up for all others. Watch out for the overhangs of joints and over legs.